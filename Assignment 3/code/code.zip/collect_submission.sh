rm -f assignment3.zip
zip -r assignment3.zip *.py ./chr_en_data ./sanity_check_en_es_data ./outputs